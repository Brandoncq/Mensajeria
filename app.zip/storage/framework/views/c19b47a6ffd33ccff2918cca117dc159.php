<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuario</title>
    <link rel="icon" type="image/png" href="/img/logo.png">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="font-sans bg-gray-50">

<div class="w-full mx-auto">
    <!-- Header -->
    <div class="w-full mx-auto p-4 bg-[#c1392b] flex items-center justify-between">
        <div>
            <h1 class="text-4xl font-extralight text-gray-100 mb-2">Panel de Administrador</h1>
            <h2 class="text-2xl font-semibold text-gray-100">Editar Usuario #<?php echo e($usuario->id_usuario); ?></h2>
        </div>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="bg-gray-100 text-[#c1392b] font-bold px-4 py-2 rounded-lg shadow hover:bg-gray-200 transition">
                <i class="fa fa-sign-out-alt"></i> Cerrar sesión
            </button>
        </form>
    </div>

    <!-- Formulario -->
    <div class="max-w-3xl mx-auto mt-8 bg-white shadow-md rounded-lg p-6">
        <!-- Mensajes de éxito -->
        <?php if(session('success')): ?>
            <div class="mb-4 p-3 bg-green-100 text-green-800 rounded">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Mensajes de error general -->
        <?php if(session('error')): ?>
            <div class="mb-4 p-3 bg-red-100 text-red-800 rounded">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <!-- Errores de validación -->
        <?php if($errors->any()): ?>
            <div class="mb-4 p-3 bg-red-100 text-red-800 rounded">
                <h3 class="font-semibold mb-2">Errores de validación:</h3>
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.usuarios.update', $usuario->id_usuario)); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

            <!-- Nombre -->
            <div>
                <label for="nombre" class="block text-lg font-medium text-gray-700">Nombre *</label>
                <input type="text" name="nombre" id="nombre" value="<?php echo e(old('nombre', $usuario->nombre)); ?>" required
                    class="mt-1 p-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm">
                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Email -->
            <div>
                <label for="email" class="block text-lg font-medium text-gray-700">Email *</label>
                <input type="email" name="email" id="email" value="<?php echo e(old('email', $usuario->email)); ?>" required
                    class="mt-1 p-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Teléfono -->
            <div>
                <label for="telefono" class="block text-lg font-medium text-gray-700">Teléfono *</label>
                <input type="text" name="telefono" id="telefono" value="<?php echo e(old('telefono', $usuario->telefono)); ?>" required
                    maxlength="9" pattern="[0-9]{9}" inputmode="numeric"
                    oninput="this.value = this.value.replace(/[^0-9]/g, '')"
                    class="mt-1 p-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm">
                <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- DNI -->
            <div>
                <label for="dni" class="block text-lg font-medium text-gray-700">DNI *</label>
                <input type="text" name="dni" id="dni" value="<?php echo e(old('dni', $usuario->dni)); ?>" required
                    maxlength="8" pattern="[0-9]{8}" inputmode="numeric"
                    oninput="this.value = this.value.replace(/[^0-9]/g, '')"
                    class="mt-1 p-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm">
                <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Rol -->
            <div>
                <label for="rol" class="block text-lg font-medium text-gray-700">Rol *</label>
                <select name="rol" id="rol" required
                    class="mt-1 p-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm">
                    <option value="monitor" <?php echo e(old('rol', $usuario->rol) == 'monitor' ? 'selected' : ''); ?>>Monitor</option>
                    <option value="administrador" <?php echo e(old('rol', $usuario->rol) == 'administrador' ? 'selected' : ''); ?>>Administrador</option>
                    <option value="asociado" <?php echo e(old('rol', $usuario->rol) == 'asociado' ? 'selected' : ''); ?>>Asociado</option>
                </select>
                <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Activo -->
            <div>
                <label for="activo" class="block text-lg font-medium text-gray-700">Estado *</label>
                <select name="activo" id="activo" required
                    class="mt-1 p-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm">
                    <option value="1" <?php echo e(old('activo', $usuario->activo) == '1' ? 'selected' : ''); ?>>Activo</option>
                    <option value="0" <?php echo e(old('activo', $usuario->activo) == '0' ? 'selected' : ''); ?>>Inactivo</option>
                </select>
                <?php $__errorArgs = ['activo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Botones -->
            <div class="flex justify-end space-x-4">
                <a href="<?php echo e(url('dashboardAdministrador')); ?>"
                    class="px-4 py-2 text-gray-600 border border-gray-400 rounded hover:bg-gray-100 transition">Cancelar</a>
                <button type="submit"
                    class="px-4 py-2 bg-[#c1392b] text-white rounded hover:bg-red-700 transition">Guardar Cambios</button>
            </div>
        </form>
    </div>
</div>

</body>
</html><?php /**PATH E:\Proyectos-Laravel\app\resources\views/dashboard/admin/usuarios/edit.blade.php ENDPATH**/ ?>